منبه الذاكرين - مشروع Flutter (واجهة واحدة)

لماذا ظهرت "الصفحة غير موجودة"؟
الملف الذي رُفع إلى AppsGeyser هو مشروع Flutter (كود مصدري)، وهذا الموقع يغلّف
ملفات الويب (HTML) فقط، فلا يجد صفحة ليعرضها. مشروع Flutter يجب أن يُبنى بأداة Flutter.

طريقة الحصول على APK:
1) ثبّت Flutter (https://flutter.dev)
2) في مجلد فارغ:  flutter create dhikr_reminder
3) انسخ إلى المشروع الجديد (مع الاستبدال): lib/ ، pubspec.yaml ، assets/
4) عدّل android/app/src/main/AndroidManifest.xml حسب android_manifest_snippet
   وتأكد أن minSdk = 23 أو أعلى
5) flutter pub get
6) flutter build apk --release
   الملف الناتج: build/app/outputs/flutter-apk/app-release.apk

بدون جهاز كمبيوتر: ارفع المجلد إلى GitHub واستخدم GitHub Actions أو Codemagic لبناء الـAPK.
