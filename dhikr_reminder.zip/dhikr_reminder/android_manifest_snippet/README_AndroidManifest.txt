افتح الملف: android/app/src/main/AndroidManifest.xml

1) أضف هذه الصلاحيات داخل <manifest> وقبل <application>:

    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"/>

2) أضف هذا داخل <application> (بجانب <activity>):

    <service
        android:name="com.pravera.flutter_foreground_task.service.ForegroundService"
        android:foregroundServiceType="mediaPlayback"
        android:exported="false"/>

    <receiver
        android:name="com.pravera.flutter_foreground_task.service.RebootReceiver"
        android:enabled="true"
        android:exported="true">
        <intent-filter>
            <action android:name="android.intent.action.BOOT_COMPLETED"/>
            <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
        </intent-filter>
    </receiver>

3) في android/app/build.gradle(.kts) تأكد أن minSdk = 23 أو أعلى.
